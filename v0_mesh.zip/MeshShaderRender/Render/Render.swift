//
//  Render.swift
//  MeshShaderRender
//
//  Created by Rui Zhou on 6/22/24.
//

import MetalKit

class Render: NSObject, MTKViewDelegate {
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        print("drawable Size will change to \(size)")
    }
    func draw(in view: MTKView) {
        //
        frameSemaphore.wait()
        
        guard let commandBuffer = commandQueue.makeCommandBuffer() else {
            print("cannot make command buffer")
            return
        }
        
        guard let renderPassDescriptor = view.currentRenderPassDescriptor else {
            print("cannot get current render pass descriptor")
            return
        }
        
        guard let renderCommandEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor) else { return }
        
        // update cameraAngle
        
//        if self.world.cameraAngle > 360.0 {
//            self.world.cameraAngle = 0.05
//        }else{
            self.world.cameraAngle += 0.01
//        }
        // get view's width and height
        let w = view.frame.width
        let h = view.frame.height
        
        let aspectRatio = w / h
        let projectionMatrix = float4x4(
            perspectiveProjectionRHFovY: radians_from_degrees(103.0),
            aspectRatio: Float(aspectRatio),
            nearZ: 0.1,
            farZ: 100.0)
        
        
        let transform =
        float4x4(rotationAroundAxis: SIMD3<Float>(0,1,0), by: self.world.cameraAngle) *
        float4x4(translationBy: SIMD3<Float>(0,0,15))
        
        
        drawSpheres(at: transform, projMat: projectionMatrix, in: renderCommandEncoder)
//        print("transform: \(transform)")
        
        renderCommandEncoder.endEncoding()
        
        //
        if let drawable = view.currentDrawable{
            commandBuffer.present(drawable)
        }
        
        commandBuffer.addCompletedHandler { _ in
            self.frameSemaphore.signal()
        }
        
        commandBuffer.commit()
        
    }
    

    
    let device: MTLDevice
    let commandQueue: MTLCommandQueue
    let renderPipelineState: MTLRenderPipelineState
    let depthStencilState: MTLDepthStencilState
//    let vertexBuffer: MTLBuffer
//    let fragmentBuffer: MTLBuffer
    
//
    var parent: RenderView
    var world: Word
    
    let frameSemaphore = DispatchSemaphore(value: 3)
    var constantBuffer : MTLBuffer
    
    init(_ parent:RenderView){
        self.parent = parent
        
        self.device = MTLCreateSystemDefaultDevice()!
        
        self.world = Word(device: self.device,vertexDescriptor: vertexDescriptor)
        
        self.commandQueue = device.makeCommandQueue()!
        self.depthStencilState = Render.makeDepthStencilState(device: self.device)
        
        do{
            self.renderPipelineState = try Render.makeRenderPipelineState(devive: self.device, vertexDescriptor: self.vertexDescriptor)
        }catch{
            fatalError("cannot make render pipeline state")
        }
        
        self.constantBuffer = device.makeBuffer(length: 65536, options: .storageModeShared)!
        
        super.init()
        
        
        
    }
    
    
    
    func drawSpheres(at transfrom:float4x4,projMat:float4x4, in renderCommandEncoder:MTLRenderCommandEncoder){
        renderCommandEncoder.setRenderPipelineState(renderPipelineState)
        renderCommandEncoder.setDepthStencilState(depthStencilState)
        
        
        
        var offset = 0
        
        var constants = InstanceConstants(modelViewProjectionMatrix: float4x4(), normalMatrix: transfrom, color: float4())
        
        
        let viewMatrix = transfrom.inverse
        
        for sphere in self.world.Spheres{
            
            constants.color = sphere.material.color
            constants.normalMatrix = viewMatrix * sphere.transform
            constants.modelViewProjectionMatrix = projMat * viewMatrix * sphere.transform
            
            renderCommandEncoder.setVertexBytes(&constants, length: MemoryLayout<InstanceConstants>.size, index: 1)
            
//            memcpy(constantBuffer.contents(), &constants, MemoryLayout<InstanceConstants>.size)
//            renderCommandEncoder.setVertexBufferOffset(offset, index: 1)
            
            if let mesh = sphere.mesh{
                for (index,vertexBuffer) in mesh.vertexBuffers.enumerated(){
                    renderCommandEncoder.setVertexBuffer(vertexBuffer.buffer, offset: vertexBuffer.offset, index: index)
                }
                
                for submesh in mesh.submeshes{
                    renderCommandEncoder.setTriangleFillMode(.fill)
                    renderCommandEncoder.drawIndexedPrimitives(type: submesh.primitiveType, indexCount: submesh.indexCount, indexType: submesh.indexType, indexBuffer: submesh.indexBuffer.buffer, indexBufferOffset: submesh.indexBuffer.offset)
                }
            }            
        }
        
        
    }
    
    
    
    //
    class func makeDepthStencilState(device:MTLDevice)->MTLDepthStencilState{
        let depthStateDescriptor = MTLDepthStencilDescriptor()
        depthStateDescriptor.depthCompareFunction = .less
        depthStateDescriptor.isDepthWriteEnabled = true
        return device.makeDepthStencilState(descriptor:depthStateDescriptor)!
        
    }
    
    class func makeRenderPipelineState(devive:MTLDevice,vertexDescriptor:MDLVertexDescriptor)  throws -> MTLRenderPipelineState{
        guard let library = devive.makeDefaultLibrary() else {
            throw RendererInitError(description: "failed to create default metal library")
        }
        
        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        
        pipelineDescriptor.vertexFunction = library.makeFunction(name: "vertex_main")
        pipelineDescriptor.fragmentFunction = library.makeFunction(name: "fragment_main")
        pipelineDescriptor.colorAttachments[0].pixelFormat = .bgra8Unorm
        pipelineDescriptor.rasterSampleCount = 4
        pipelineDescriptor.depthAttachmentPixelFormat = .depth32Float
        
        
        
        
        pipelineDescriptor.vertexDescriptor = MTKMetalVertexDescriptorFromModelIO(vertexDescriptor)
        
        return try devive.makeRenderPipelineState(descriptor: pipelineDescriptor)
    }
    
    var vertexDescriptor: MDLVertexDescriptor = {
        let vertexDescriptor = MDLVertexDescriptor()
        vertexDescriptor.attributes[0] = MDLVertexAttribute(name: MDLVertexAttributePosition, format: .float3, offset: 0, bufferIndex: 0)
        vertexDescriptor.attributes[1] = MDLVertexAttribute(name: MDLVertexAttributeNormal, format: .float3, offset: MemoryLayout<Float>.size * 3, bufferIndex: 0)
        vertexDescriptor.layouts[0] = MDLVertexBufferLayout(stride: MemoryLayout<Float>.size * 6)

        return vertexDescriptor
    }()
    
    
    
}

