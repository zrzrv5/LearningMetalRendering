//
//  Render.swift
//  MeshShaderRender
//
//  Created by Rui Zhou on 6/22/24.
//

import MetalKit

class Render: NSObject, MTKViewDelegate {
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        print("drawable Size will change to \(size)")
    }
    func draw(in view: MTKView) {
        //
        frameSemaphore.wait()
        
        guard let commandBuffer = commandQueue.makeCommandBuffer() else {
            print("cannot make command buffer")
            return
        }
        
        guard let renderPassDescriptor = view.currentRenderPassDescriptor else {
            print("cannot get current render pass descriptor")
            return
        }
        
        guard let renderCommandEncoder = commandBuffer.makeRenderCommandEncoder(descriptor: renderPassDescriptor) else { return }
        
        // update cameraAngle
        
//        if self.world.cameraAngle > 360.0 {
//            self.world.cameraAngle = 0.05
//        }else{
            self.world.cameraAngle += 0.01
//        }
        // get view's width and height
        let w = view.frame.width
        let h = view.frame.height
        
        let aspectRatio = w / h
        let projectionMatrix = float4x4(
            perspectiveProjectionRHFovY: radians_from_degrees(65),
            aspectRatio: Float(aspectRatio),
            nearZ: 0.1,
            farZ: 100.0)
        
        let eye = SIMD3<Float>(15 * sin(world.cameraAngle), 0, 15 * cos(world.cameraAngle))
        let center = SIMD3<Float>(0, 0, 0)
        let up = SIMD3<Float>(0, 1, 0)
        
        let viewMatrix = float4x4(lookAt: eye, center: center, up: up)
        
        
        var viewProjectionMatrix = projectionMatrix * viewMatrix
        
        drawSpheres(viewProjMat: &viewProjectionMatrix, in: renderCommandEncoder)
//        print("transform: \(transform)")
        
        renderCommandEncoder.endEncoding()
        
        //
        if let drawable = view.currentDrawable{
            commandBuffer.present(drawable)
        }
        
        commandBuffer.addCompletedHandler { _ in
            self.frameSemaphore.signal()
        }
        
        commandBuffer.commit()
        
    }
    

    
    let device: MTLDevice
    let commandQueue: MTLCommandQueue
    let renderPipelineState: MTLRenderPipelineState
    let depthStencilState: MTLDepthStencilState
//    let vertexBuffer: MTLBuffer
//    let fragmentBuffer: MTLBuffer
    
//
    var parent: RenderView
    var world: Word
    
    let frameSemaphore = DispatchSemaphore(value: 3)
    var instanceBuffer : MTLBuffer!
    
    
    init(_ parent:RenderView){
        self.parent = parent
        
        self.device = MTLCreateSystemDefaultDevice()!
        
        self.world = Word(device: self.device,vertexDescriptor: vertexDescriptor)
        
        self.commandQueue = device.makeCommandQueue()!
        self.depthStencilState = Render.makeDepthStencilState(device: self.device)
        
        do{
            self.renderPipelineState = try Render.makeRenderPipelineState(devive: self.device, vertexDescriptor: self.vertexDescriptor)
        }catch{
            fatalError("cannot make render pipeline state")
        }
        
        
        var instanceData = [InstanceData]()
        for sphere in self.world.Spheres{
            instanceData.append(
                InstanceData(modelMatrix: sphere.transform, normalMatrix: sphere.transform.transpose.inverse, color: sphere.material.color))
        }
        instanceBuffer = device.makeBuffer(bytes: instanceData, length: MemoryLayout<InstanceData>.stride*instanceData.count)!
        
        super.init()
 
        
    }
    
    
    
    func drawSpheres( viewProjMat: inout float4x4, in renderCommandEncoder:MTLRenderCommandEncoder){
        renderCommandEncoder.setRenderPipelineState(renderPipelineState)
        renderCommandEncoder.setDepthStencilState(depthStencilState)
        

        renderCommandEncoder.setVertexBuffer(self.world.sphereMesh.vertexBuffers[0].buffer, offset: 0, index: 0)
        renderCommandEncoder.setVertexBuffer(self.instanceBuffer,offset: 0,index: 1)
        renderCommandEncoder.setVertexBytes(&viewProjMat, length: MemoryLayout<float4x4>.size, index: 2)
        
        for submesh in self.world.sphereMesh.submeshes{
            renderCommandEncoder.setTriangleFillMode(.fill)
            renderCommandEncoder.drawIndexedPrimitives(
                type: submesh.primitiveType,
                indexCount: submesh.indexCount,
                indexType: submesh.indexType,
                indexBuffer: submesh.indexBuffer.buffer,
                indexBufferOffset: submesh.indexBuffer.offset,
                instanceCount: self.world.Spheres.count
            )
        }
                
        
        
    }

        
    
    
    
    //
    class func makeDepthStencilState(device:MTLDevice)->MTLDepthStencilState{
        let depthStateDescriptor = MTLDepthStencilDescriptor()
        depthStateDescriptor.depthCompareFunction = .less
        depthStateDescriptor.isDepthWriteEnabled = true
        return device.makeDepthStencilState(descriptor:depthStateDescriptor)!
        
    }
    
    class func makeRenderPipelineState(devive:MTLDevice,vertexDescriptor:MDLVertexDescriptor)  throws -> MTLRenderPipelineState{
        guard let library = devive.makeDefaultLibrary() else {
            throw RendererInitError(description: "failed to create default metal library")
        }
        
        let pipelineDescriptor = MTLRenderPipelineDescriptor()
        
        pipelineDescriptor.vertexFunction = library.makeFunction(name: "vertex_main")
        pipelineDescriptor.fragmentFunction = library.makeFunction(name: "fragment_main")
        pipelineDescriptor.colorAttachments[0].pixelFormat = .bgra8Unorm
        pipelineDescriptor.rasterSampleCount = 4
        pipelineDescriptor.depthAttachmentPixelFormat = .depth32Float
        
        
        
        
        let metalVertexDescriptor = MTKMetalVertexDescriptorFromModelIO(vertexDescriptor)
        metalVertexDescriptor?.layouts[1].stepFunction = .perInstance
        metalVertexDescriptor?.layouts[1].stepRate = 1
        
        pipelineDescriptor.vertexDescriptor = metalVertexDescriptor
        
        
        return try devive.makeRenderPipelineState(descriptor: pipelineDescriptor)
    }
    
    var vertexDescriptor: MDLVertexDescriptor = {
        let vertexDescriptor = MDLVertexDescriptor()
        
        // per-vertex attributes
        vertexDescriptor.attributes[0] = MDLVertexAttribute(name: MDLVertexAttributePosition, format: .float3, offset: 0, bufferIndex: 0)
        vertexDescriptor.attributes[1] = MDLVertexAttribute(name: MDLVertexAttributeNormal, format: .float3, offset: MemoryLayout<Float>.size * 3, bufferIndex: 0)
        vertexDescriptor.layouts[0] = MDLVertexBufferLayout(stride: MemoryLayout<Float>.size * 6)
        
        // per-instance attributes
        // 4x4 model matrix
            vertexDescriptor.attributes[2] = MDLVertexAttribute(name: "instance_modelMatrix", format: .float4, offset: 0, bufferIndex: 1)
            vertexDescriptor.attributes[3] = MDLVertexAttribute(name: "instance_modelMatrix", format: .float4, offset: MemoryLayout<Float>.size * 4, bufferIndex: 1)
            vertexDescriptor.attributes[4] = MDLVertexAttribute(name: "instance_modelMatrix", format: .float4, offset: MemoryLayout<Float>.size * 8, bufferIndex: 1)
            vertexDescriptor.attributes[5] = MDLVertexAttribute(name: "instance_modelMatrix", format: .float4, offset: MemoryLayout<Float>.size * 12, bufferIndex: 1)
        // 4x4 normal matrix
        
            vertexDescriptor.attributes[6] = MDLVertexAttribute(name: "instance_normalMatrix", format: .float4, offset: MemoryLayout<Float>.size * 16, bufferIndex: 1)
            vertexDescriptor.attributes[7] = MDLVertexAttribute(name: "instance_normalMatrix", format: .float4, offset: MemoryLayout<Float>.size * 20, bufferIndex: 1)
            vertexDescriptor.attributes[8] = MDLVertexAttribute(name: "instance_normalMatrix", format: .float4, offset: MemoryLayout<Float>.size * 24, bufferIndex: 1)
            vertexDescriptor.attributes[9] = MDLVertexAttribute(name: "instance_normalMatrix", format: .float4, offset: MemoryLayout<Float>.size * 28, bufferIndex: 1)
            vertexDescriptor.attributes[10] = MDLVertexAttribute(name: "instance_color", format: .float4, offset: MemoryLayout<Float>.size * 32, bufferIndex: 1)
        
            vertexDescriptor.layouts[1] = MDLVertexBufferLayout(stride: MemoryLayout<Float>.size * 36)
        

        return vertexDescriptor
    }()
    
    
    
}

