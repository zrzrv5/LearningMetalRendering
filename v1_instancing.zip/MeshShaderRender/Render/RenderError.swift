//
//  RenderError.swift
//  MeshShaderRender
//
//  Created by Rui Zhou on 6/22/24.
//

struct RendererInitError: Error {
    var description: String
}
